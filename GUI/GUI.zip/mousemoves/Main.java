/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package GUI.mousemoves;

/**
 *
 * @author Elizabeth
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		MouseMoves frame = new MouseMoves();
		frame.createGui();
		frame.setVisible(true);
    }

}
