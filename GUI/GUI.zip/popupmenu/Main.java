/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package GUI.popupmenu;

/**
 * @author Elizabeth
 */
public class Main {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		PopupMenuDemo frame = new PopupMenuDemo();
		frame.createGUI();
		frame.setVisible(true); 
	}

}
