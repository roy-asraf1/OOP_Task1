/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package GUI.simplegui;

/**
 *
 * @author Elizabeth
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		SimpleGUI app = new SimpleGUI();
// Shows or hides this component depending on the value of parameter b
		app.setVisible(true);
    }

}
