/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.menudemo;

/**
 *
 * @author Elizabeth
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MenuDemo frame = new MenuDemo();
        frame.setSize(250, 200);
        frame.createGui();
        frame.setVisible(true);
    }
}
