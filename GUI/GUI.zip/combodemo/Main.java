/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package GUI.combodemo;
public class Main {
    public static void main(String[] args) {
		ComboDemo frame = new ComboDemo();
		frame.createGui();
		frame.setVisible(true);
    }
}
